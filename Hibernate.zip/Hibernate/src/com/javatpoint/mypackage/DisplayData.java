package com.javatpoint.mypackage;  
import org.hibernate.*;
import java.util.List;
import org.hibernate.cfg.*;
import org.hibernate.boot.Metadata;  
import org.hibernate.boot.MetadataSources;  
import org.hibernate.boot.registry.StandardServiceRegistry;  
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;  
  
public class DisplayData {  
  
    public static void main( String[] args )  
    {  
         StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
            Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();  
          
        SessionFactory factory = meta.getSessionFactoryBuilder().build();  
        Session session = factory.openSession();  
     
        Query<Employee> query=session.createQuery("FROM Employee",Employee.class);
        List<Employee> list = query.list();
       
        for (Employee employee : list) {
        	
        	System.out.println(employee.toStringAll());
        }
      
  
        factory.close();  
        session.close();     
    }  
}  